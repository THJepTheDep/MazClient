Make sure to extrack all files before using the Client 

the ll should always be named "csgo.dll"