Make sure to extrack all files before using the Client 

the dll. should always be named "csgo.dll" no matter what.